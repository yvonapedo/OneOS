#ifndef CCONFIG_H__
#define CCONFIG_H__
/* Automatically generated file; DO NOT EDIT. */
/* compiler configure file for CMCC IOT in GCC*/

#define HAVE_NEWLIB_H 1
#define LIBC_VERSION "newlib 3.3.0"

#define HAVE_SYS_SIGNAL_H 1
#define HAVE_SYS_SELECT_H 1
#define HAVE_PTHREAD_H 1

#define HAVE_FDSET 1
#define HAVE_SIGACTION 1
#define HAVE_SIGEVENT 1
#define HAVE_SIGINFO 1
#define HAVE_SIGVAL 1
#define GCC_VERSION "9.3.1 20200408 (release)"
#define STDC "2011"

#endif
